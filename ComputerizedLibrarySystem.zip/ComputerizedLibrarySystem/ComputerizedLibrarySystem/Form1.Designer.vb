﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.pnlContainer = New Bunifu.Framework.UI.BunifuGradientPanel()
        Me.lblTitle = New System.Windows.Forms.Label()
        Me.btnBooks = New Bunifu.Framework.UI.BunifuFlatButton()
        Me.btnBorrower = New Bunifu.Framework.UI.BunifuFlatButton()
        Me.btnBorrowBooks = New Bunifu.Framework.UI.BunifuFlatButton()
        Me.btnReturn = New Bunifu.Framework.UI.BunifuFlatButton()
        Me.btnOverdues = New Bunifu.Framework.UI.BunifuFlatButton()
        Me.btnUser = New Bunifu.Framework.UI.BunifuFlatButton()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Panel1.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Panel2
        '
        Me.Panel2.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(102, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.Panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel2.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel2.Location = New System.Drawing.Point(0, 0)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(1049, 26)
        Me.Panel2.TabIndex = 1
        '
        'pnlContainer
        '
        Me.pnlContainer.BackgroundImage = CType(resources.GetObject("pnlContainer.BackgroundImage"), System.Drawing.Image)
        Me.pnlContainer.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.pnlContainer.GradientBottomLeft = System.Drawing.Color.White
        Me.pnlContainer.GradientBottomRight = System.Drawing.Color.White
        Me.pnlContainer.GradientTopLeft = System.Drawing.Color.White
        Me.pnlContainer.GradientTopRight = System.Drawing.Color.White
        Me.pnlContainer.Location = New System.Drawing.Point(184, 107)
        Me.pnlContainer.Name = "pnlContainer"
        Me.pnlContainer.Quality = 10
        Me.pnlContainer.Size = New System.Drawing.Size(859, 446)
        Me.pnlContainer.TabIndex = 2
        '
        'lblTitle
        '
        Me.lblTitle.AutoSize = True
        Me.lblTitle.Font = New System.Drawing.Font("Century Gothic", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTitle.ForeColor = System.Drawing.Color.White
        Me.lblTitle.Location = New System.Drawing.Point(185, 77)
        Me.lblTitle.Name = "lblTitle"
        Me.lblTitle.Size = New System.Drawing.Size(46, 23)
        Me.lblTitle.TabIndex = 4
        Me.lblTitle.Text = "Title"
        '
        'btnBooks
        '
        Me.btnBooks.Activecolor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(102, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.btnBooks.BackColor = System.Drawing.Color.FromArgb(CType(CType(26, Byte), Integer), CType(CType(32, Byte), Integer), CType(CType(40, Byte), Integer))
        Me.btnBooks.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.btnBooks.BorderRadius = 0
        Me.btnBooks.ButtonText = "             Books"
        Me.btnBooks.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnBooks.DisabledColor = System.Drawing.Color.Gray
        Me.btnBooks.Font = New System.Drawing.Font("Century Gothic", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnBooks.Iconcolor = System.Drawing.Color.Transparent
        Me.btnBooks.Iconimage = Nothing
        Me.btnBooks.Iconimage_right = Nothing
        Me.btnBooks.Iconimage_right_Selected = Nothing
        Me.btnBooks.Iconimage_Selected = Nothing
        Me.btnBooks.IconMarginLeft = 0
        Me.btnBooks.IconMarginRight = 0
        Me.btnBooks.IconRightVisible = True
        Me.btnBooks.IconRightZoom = 0R
        Me.btnBooks.IconVisible = True
        Me.btnBooks.IconZoom = 90.0R
        Me.btnBooks.IsTab = True
        Me.btnBooks.Location = New System.Drawing.Point(1, 114)
        Me.btnBooks.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.btnBooks.Name = "btnBooks"
        Me.btnBooks.Normalcolor = System.Drawing.Color.FromArgb(CType(CType(26, Byte), Integer), CType(CType(32, Byte), Integer), CType(CType(40, Byte), Integer))
        Me.btnBooks.OnHovercolor = System.Drawing.Color.FromArgb(CType(CType(26, Byte), Integer), CType(CType(32, Byte), Integer), CType(CType(40, Byte), Integer))
        Me.btnBooks.OnHoverTextColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(102, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.btnBooks.selected = False
        Me.btnBooks.Size = New System.Drawing.Size(177, 33)
        Me.btnBooks.TabIndex = 2
        Me.btnBooks.Text = "             Books"
        Me.btnBooks.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnBooks.Textcolor = System.Drawing.Color.White
        Me.btnBooks.TextFont = New System.Drawing.Font("Century Gothic", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        '
        'btnBorrower
        '
        Me.btnBorrower.Activecolor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(102, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.btnBorrower.BackColor = System.Drawing.Color.FromArgb(CType(CType(26, Byte), Integer), CType(CType(32, Byte), Integer), CType(CType(40, Byte), Integer))
        Me.btnBorrower.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.btnBorrower.BorderRadius = 0
        Me.btnBorrower.ButtonText = "          Borrower"
        Me.btnBorrower.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnBorrower.DisabledColor = System.Drawing.Color.Gray
        Me.btnBorrower.Font = New System.Drawing.Font("Century", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnBorrower.Iconcolor = System.Drawing.Color.Transparent
        Me.btnBorrower.Iconimage = Nothing
        Me.btnBorrower.Iconimage_right = Nothing
        Me.btnBorrower.Iconimage_right_Selected = Nothing
        Me.btnBorrower.Iconimage_Selected = Nothing
        Me.btnBorrower.IconMarginLeft = 0
        Me.btnBorrower.IconMarginRight = 0
        Me.btnBorrower.IconRightVisible = True
        Me.btnBorrower.IconRightZoom = 0R
        Me.btnBorrower.IconVisible = True
        Me.btnBorrower.IconZoom = 90.0R
        Me.btnBorrower.IsTab = True
        Me.btnBorrower.Location = New System.Drawing.Point(1, 163)
        Me.btnBorrower.Name = "btnBorrower"
        Me.btnBorrower.Normalcolor = System.Drawing.Color.FromArgb(CType(CType(26, Byte), Integer), CType(CType(32, Byte), Integer), CType(CType(40, Byte), Integer))
        Me.btnBorrower.OnHovercolor = System.Drawing.Color.FromArgb(CType(CType(26, Byte), Integer), CType(CType(32, Byte), Integer), CType(CType(40, Byte), Integer))
        Me.btnBorrower.OnHoverTextColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(102, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.btnBorrower.selected = False
        Me.btnBorrower.Size = New System.Drawing.Size(175, 32)
        Me.btnBorrower.TabIndex = 3
        Me.btnBorrower.Text = "          Borrower"
        Me.btnBorrower.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnBorrower.Textcolor = System.Drawing.Color.White
        Me.btnBorrower.TextFont = New System.Drawing.Font("Century Gothic", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        '
        'btnBorrowBooks
        '
        Me.btnBorrowBooks.Activecolor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(102, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.btnBorrowBooks.BackColor = System.Drawing.Color.FromArgb(CType(CType(26, Byte), Integer), CType(CType(32, Byte), Integer), CType(CType(40, Byte), Integer))
        Me.btnBorrowBooks.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.btnBorrowBooks.BorderRadius = 0
        Me.btnBorrowBooks.ButtonText = "       Borrow Books"
        Me.btnBorrowBooks.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnBorrowBooks.DisabledColor = System.Drawing.Color.Gray
        Me.btnBorrowBooks.Font = New System.Drawing.Font("Century", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnBorrowBooks.Iconcolor = System.Drawing.Color.Transparent
        Me.btnBorrowBooks.Iconimage = Nothing
        Me.btnBorrowBooks.Iconimage_right = Nothing
        Me.btnBorrowBooks.Iconimage_right_Selected = Nothing
        Me.btnBorrowBooks.Iconimage_Selected = Nothing
        Me.btnBorrowBooks.IconMarginLeft = 0
        Me.btnBorrowBooks.IconMarginRight = 0
        Me.btnBorrowBooks.IconRightVisible = True
        Me.btnBorrowBooks.IconRightZoom = 0R
        Me.btnBorrowBooks.IconVisible = True
        Me.btnBorrowBooks.IconZoom = 90.0R
        Me.btnBorrowBooks.IsTab = True
        Me.btnBorrowBooks.Location = New System.Drawing.Point(1, 220)
        Me.btnBorrowBooks.Name = "btnBorrowBooks"
        Me.btnBorrowBooks.Normalcolor = System.Drawing.Color.FromArgb(CType(CType(26, Byte), Integer), CType(CType(32, Byte), Integer), CType(CType(40, Byte), Integer))
        Me.btnBorrowBooks.OnHovercolor = System.Drawing.Color.FromArgb(CType(CType(26, Byte), Integer), CType(CType(32, Byte), Integer), CType(CType(40, Byte), Integer))
        Me.btnBorrowBooks.OnHoverTextColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(102, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.btnBorrowBooks.selected = False
        Me.btnBorrowBooks.Size = New System.Drawing.Size(175, 29)
        Me.btnBorrowBooks.TabIndex = 4
        Me.btnBorrowBooks.Text = "       Borrow Books"
        Me.btnBorrowBooks.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnBorrowBooks.Textcolor = System.Drawing.Color.White
        Me.btnBorrowBooks.TextFont = New System.Drawing.Font("Century Gothic", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        '
        'btnReturn
        '
        Me.btnReturn.Activecolor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(102, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.btnReturn.BackColor = System.Drawing.Color.FromArgb(CType(CType(26, Byte), Integer), CType(CType(32, Byte), Integer), CType(CType(40, Byte), Integer))
        Me.btnReturn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.btnReturn.BorderRadius = 0
        Me.btnReturn.ButtonText = "       Return Books"
        Me.btnReturn.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnReturn.DisabledColor = System.Drawing.SystemColors.GrayText
        Me.btnReturn.Font = New System.Drawing.Font("Century", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnReturn.Iconcolor = System.Drawing.Color.Transparent
        Me.btnReturn.Iconimage = Nothing
        Me.btnReturn.Iconimage_right = Nothing
        Me.btnReturn.Iconimage_right_Selected = Nothing
        Me.btnReturn.Iconimage_Selected = Nothing
        Me.btnReturn.IconMarginLeft = 0
        Me.btnReturn.IconMarginRight = 0
        Me.btnReturn.IconRightVisible = True
        Me.btnReturn.IconRightZoom = 0R
        Me.btnReturn.IconVisible = True
        Me.btnReturn.IconZoom = 90.0R
        Me.btnReturn.IsTab = True
        Me.btnReturn.Location = New System.Drawing.Point(1, 273)
        Me.btnReturn.Name = "btnReturn"
        Me.btnReturn.Normalcolor = System.Drawing.Color.FromArgb(CType(CType(26, Byte), Integer), CType(CType(32, Byte), Integer), CType(CType(40, Byte), Integer))
        Me.btnReturn.OnHovercolor = System.Drawing.Color.FromArgb(CType(CType(26, Byte), Integer), CType(CType(32, Byte), Integer), CType(CType(40, Byte), Integer))
        Me.btnReturn.OnHoverTextColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(102, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.btnReturn.selected = False
        Me.btnReturn.Size = New System.Drawing.Size(175, 32)
        Me.btnReturn.TabIndex = 5
        Me.btnReturn.Text = "       Return Books"
        Me.btnReturn.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnReturn.Textcolor = System.Drawing.Color.White
        Me.btnReturn.TextFont = New System.Drawing.Font("Century Gothic", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        '
        'btnOverdues
        '
        Me.btnOverdues.Activecolor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(102, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.btnOverdues.BackColor = System.Drawing.Color.FromArgb(CType(CType(26, Byte), Integer), CType(CType(32, Byte), Integer), CType(CType(40, Byte), Integer))
        Me.btnOverdues.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.btnOverdues.BorderRadius = 0
        Me.btnOverdues.ButtonText = "    Overdue Books"
        Me.btnOverdues.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnOverdues.DisabledColor = System.Drawing.Color.Gray
        Me.btnOverdues.Font = New System.Drawing.Font("Century", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnOverdues.Iconcolor = System.Drawing.Color.Transparent
        Me.btnOverdues.Iconimage = Nothing
        Me.btnOverdues.Iconimage_right = Nothing
        Me.btnOverdues.Iconimage_right_Selected = Nothing
        Me.btnOverdues.Iconimage_Selected = Nothing
        Me.btnOverdues.IconMarginLeft = 0
        Me.btnOverdues.IconMarginRight = 0
        Me.btnOverdues.IconRightVisible = True
        Me.btnOverdues.IconRightZoom = 0R
        Me.btnOverdues.IconVisible = True
        Me.btnOverdues.IconZoom = 90.0R
        Me.btnOverdues.IsTab = True
        Me.btnOverdues.Location = New System.Drawing.Point(1, 323)
        Me.btnOverdues.Name = "btnOverdues"
        Me.btnOverdues.Normalcolor = System.Drawing.Color.FromArgb(CType(CType(26, Byte), Integer), CType(CType(32, Byte), Integer), CType(CType(40, Byte), Integer))
        Me.btnOverdues.OnHovercolor = System.Drawing.Color.FromArgb(CType(CType(26, Byte), Integer), CType(CType(32, Byte), Integer), CType(CType(40, Byte), Integer))
        Me.btnOverdues.OnHoverTextColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(102, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.btnOverdues.selected = False
        Me.btnOverdues.Size = New System.Drawing.Size(175, 34)
        Me.btnOverdues.TabIndex = 6
        Me.btnOverdues.Text = "    Overdue Books"
        Me.btnOverdues.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnOverdues.Textcolor = System.Drawing.Color.White
        Me.btnOverdues.TextFont = New System.Drawing.Font("Century Gothic", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        '
        'btnUser
        '
        Me.btnUser.Activecolor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(102, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.btnUser.BackColor = System.Drawing.Color.FromArgb(CType(CType(26, Byte), Integer), CType(CType(32, Byte), Integer), CType(CType(40, Byte), Integer))
        Me.btnUser.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.btnUser.BorderRadius = 0
        Me.btnUser.ButtonText = "     Manage Users"
        Me.btnUser.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnUser.DisabledColor = System.Drawing.Color.Gray
        Me.btnUser.Font = New System.Drawing.Font("Century", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnUser.Iconcolor = System.Drawing.Color.Transparent
        Me.btnUser.Iconimage = Nothing
        Me.btnUser.Iconimage_right = Nothing
        Me.btnUser.Iconimage_right_Selected = Nothing
        Me.btnUser.Iconimage_Selected = Nothing
        Me.btnUser.IconMarginLeft = 0
        Me.btnUser.IconMarginRight = 0
        Me.btnUser.IconRightVisible = True
        Me.btnUser.IconRightZoom = 0R
        Me.btnUser.IconVisible = True
        Me.btnUser.IconZoom = 90.0R
        Me.btnUser.IsTab = True
        Me.btnUser.Location = New System.Drawing.Point(-1, 378)
        Me.btnUser.Name = "btnUser"
        Me.btnUser.Normalcolor = System.Drawing.Color.FromArgb(CType(CType(26, Byte), Integer), CType(CType(32, Byte), Integer), CType(CType(40, Byte), Integer))
        Me.btnUser.OnHovercolor = System.Drawing.Color.FromArgb(CType(CType(26, Byte), Integer), CType(CType(32, Byte), Integer), CType(CType(40, Byte), Integer))
        Me.btnUser.OnHoverTextColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(102, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.btnUser.selected = False
        Me.btnUser.Size = New System.Drawing.Size(175, 32)
        Me.btnUser.TabIndex = 8
        Me.btnUser.Text = "     Manage Users"
        Me.btnUser.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnUser.Textcolor = System.Drawing.Color.White
        Me.btnUser.TextFont = New System.Drawing.Font("Century Gothic", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.FromArgb(CType(CType(26, Byte), Integer), CType(CType(32, Byte), Integer), CType(CType(40, Byte), Integer))
        Me.Panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel1.Controls.Add(Me.PictureBox1)
        Me.Panel1.Controls.Add(Me.btnUser)
        Me.Panel1.Controls.Add(Me.btnOverdues)
        Me.Panel1.Controls.Add(Me.btnReturn)
        Me.Panel1.Controls.Add(Me.btnBorrowBooks)
        Me.Panel1.Controls.Add(Me.btnBorrower)
        Me.Panel1.Controls.Add(Me.btnBooks)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Left
        Me.Panel1.Location = New System.Drawing.Point(0, 26)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(179, 531)
        Me.Panel1.TabIndex = 0
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), System.Drawing.Image)
        Me.PictureBox1.Location = New System.Drawing.Point(32, 5)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(102, 84)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1.TabIndex = 7
        Me.PictureBox1.TabStop = False
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Century Gothic", 21.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.White
        Me.Label2.Location = New System.Drawing.Point(183, 27)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(426, 36)
        Me.Label2.TabIndex = 6
        Me.Label2.Text = "Computerized Library System"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(37, Byte), Integer), CType(CType(46, Byte), Integer), CType(CType(59, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(1049, 557)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.lblTitle)
        Me.Controls.Add(Me.pnlContainer)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.Panel2)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "Form1"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Form1"
        Me.Panel1.ResumeLayout(False)
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Panel2 As Panel
    Friend WithEvents pnlContainer As Bunifu.Framework.UI.BunifuGradientPanel
    Friend WithEvents lblTitle As Label
    Friend WithEvents btnBooks As Bunifu.Framework.UI.BunifuFlatButton
    Friend WithEvents btnBorrower As Bunifu.Framework.UI.BunifuFlatButton
    Friend WithEvents btnBorrowBooks As Bunifu.Framework.UI.BunifuFlatButton
    Friend WithEvents btnReturn As Bunifu.Framework.UI.BunifuFlatButton
    Friend WithEvents btnOverdues As Bunifu.Framework.UI.BunifuFlatButton
    Friend WithEvents btnUser As Bunifu.Framework.UI.BunifuFlatButton
    Friend WithEvents Panel1 As Panel
    Friend WithEvents Label2 As Label
    Friend WithEvents PictureBox1 As PictureBox
End Class
