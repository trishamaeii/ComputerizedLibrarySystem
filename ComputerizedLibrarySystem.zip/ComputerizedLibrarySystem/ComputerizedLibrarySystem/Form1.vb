﻿Public Class Form1
    Private Sub btnLogout_Click(sender As Object, e As EventArgs)
        Me.Close()
        With frmLogin
            .Show()
            .PasswordTextBox.Clear()
            .UsernameTextBox.Clear()
            .UsernameTextBox.Focus()
        End With
    End Sub
    Private Sub addForm(frm As Form)
        pnlContainer.Controls.Clear()
        frm.TopLevel = False
        frm.TopMost = True
        frm.Dock = Dock.Fill
        pnlContainer.Controls.Add(frm)
        frm.Show()
    End Sub

    Private Sub change_menu(menu As String)

        Select Case menu
            Case "Books"

                lblTitle.Text = "Manage Books"
                addForm(frmBooks)
            Case "Borrower"

                lblTitle.Text = "Manage Borrower"
                addForm(frmBorrower)
            Case "Borrow"

                lblTitle.Text = "Borrow Books"
                addForm(frmBorrowBooks)
            Case "Return"

                lblTitle.Text = "Return Books"
                addForm(frmReturnBooks)
            Case "Overdue"

                lblTitle.Text = "Overdue"
                addForm(frmOverdue)


            Case "User"

                lblTitle.Text = "Manage Users"
                addForm(frmUser)



        End Select

    End Sub

    Private Sub btnUser_Click(sender As Object, e As EventArgs) Handles btnUser.Click

        change_menu("User")
    End Sub

    Private Sub btnBooks_Click(sender As Object, e As EventArgs) Handles btnBooks.Click
        change_menu("Books")
    End Sub

    Private Sub btnBorrower_Click(sender As Object, e As EventArgs) Handles btnBorrower.Click
        change_menu("Borrower")
    End Sub

    Private Sub btnBorrowBooks_Click(sender As Object, e As EventArgs) Handles btnBorrowBooks.Click
        change_menu("Borrow")
    End Sub

    Private Sub btnReturn_Click(sender As Object, e As EventArgs) Handles btnReturn.Click
        change_menu("Return")
    End Sub

    Private Sub btnOverdues_Click(sender As Object, e As EventArgs) Handles btnOverdues.Click
        change_menu("Overdue")
    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        change_menu("Books")
    End Sub

    Private Sub pnlContainer_Paint(sender As Object, e As PaintEventArgs) Handles pnlContainer.Paint

    End Sub

    Private Sub Label1_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub PictureBox1_Click(sender As Object, e As EventArgs) Handles PictureBox1.Click

    End Sub

    Private Sub lblTitle_Click(sender As Object, e As EventArgs) Handles lblTitle.Click

    End Sub
End Class
